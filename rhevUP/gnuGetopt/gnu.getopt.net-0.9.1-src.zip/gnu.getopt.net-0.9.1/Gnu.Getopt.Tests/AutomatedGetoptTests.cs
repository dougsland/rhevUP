using System;

using NUnit.Framework;

namespace Gnu.Getopt.Tests
{
	[TestFixture]
	public class AutomatedGetoptTests
	{
		/* todo normal test + MessageBundle globalisation tests
		[Test]
		public void AutomatedGetoptTest()
		{
		}
		*/
	}
}
